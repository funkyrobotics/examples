﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Drawing2D
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        Point DragStartPoint,DragEndPoint,ObjectStartLocation;
        object ClickedObject;
        double ClickedLineLength;

        private void DrawingCanvas_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {

            ContextMenu cm = new ContextMenu();
            cm.Placement = System.Windows.Controls.Primitives.PlacementMode.MousePoint;

            MenuItem RectangleButton = new MenuItem() { Header = "RECTANGLE" };
            MenuItem CircleButton    = new MenuItem() { Header = "CIRCLE" };
            MenuItem LineButton      = new MenuItem() { Header = "LINE" };

            RectangleButton.Click += RectangleButton_Click;
            CircleButton.Click    += CircleButton_Click;
            LineButton.Click      += LineButton_Click;

            cm.Items.Add(RectangleButton);
            cm.Items.Add(CircleButton);
            cm.Items.Add(LineButton);

            cm.IsOpen = true;


        }


        private void RectangleButton_Click(object sender, RoutedEventArgs e)
        {
            Rectangle ARectangle = new Rectangle() { Height = 150, Width = 300, Stroke = Brushes.Black, StrokeThickness = 5, Fill = Brushes.Red };

            Canvas.SetLeft(ARectangle, (DrawingCanvas.ActualWidth / 2) - (ARectangle.Width / 2));
            Canvas.SetTop(ARectangle, (DrawingCanvas.ActualHeight / 2) - (ARectangle.Height / 2));
            ARectangle.Tag = "R" + (DrawingCanvas.Children.Count - 1).ToString();

            ARectangle.PreviewMouseLeftButtonDown += ARectangle_PreviewMouseLeftButtonDown;
         

            DrawingCanvas.Children.Add(ARectangle);
        }

     

        private void ARectangle_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Rectangle r = sender as Rectangle;
            DragStartPoint.X = e.GetPosition(this).X;
            DragStartPoint.Y = e.GetPosition(this).Y;

            ObjectStartLocation.X = Canvas.GetLeft(r) ;
            ObjectStartLocation.Y = Canvas.GetTop(r)  ;

            ClickedObject = r;
        }

        private void CircleButton_Click(object sender, RoutedEventArgs e)
        {
            Ellipse ACircle = new Ellipse() { Height = 150, Width = 150, Stroke = Brushes.Black, StrokeThickness = 5, Fill = Brushes.Blue };

            Canvas.SetLeft(ACircle, (DrawingCanvas.ActualWidth / 2) - (ACircle.Width / 2));
            Canvas.SetTop(ACircle, (DrawingCanvas.ActualHeight / 2) - (ACircle.Height / 2));
            ACircle.Tag = "C" + (DrawingCanvas.Children.Count - 1).ToString();

            ACircle.PreviewMouseLeftButtonDown += ACircle_PreviewMouseLeftButtonDown;
          

            DrawingCanvas.Children.Add(ACircle);

        }

     

        private void ACircle_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Ellipse c = sender as Ellipse;
            DragStartPoint.X = e.GetPosition(this).X;
            DragStartPoint.Y = e.GetPosition(this).Y;


            ObjectStartLocation.X = Canvas.GetLeft(c);
            ObjectStartLocation.Y = Canvas.GetTop(c);

            ClickedObject = c;
        }

        private void LineButton_Click(object sender, RoutedEventArgs e)
        {

            double LineWidth  = 150;
          

            Line ALine = new Line() { Stroke = Brushes.Black, StrokeThickness = 5, Fill = Brushes.Red };

            ALine.X1 = (DrawingCanvas.ActualWidth / 2) - (LineWidth / 2);
            ALine.Y1 = (DrawingCanvas.ActualHeight / 2);
            ALine.X2 =  ALine.X1 + LineWidth;
            ALine.Y2 = (DrawingCanvas.ActualHeight / 2) ;
            ALine.Tag = "L" + (DrawingCanvas.Children.Count - 1).ToString();

            ALine.PreviewMouseLeftButtonDown += ALine_PreviewMouseLeftButtonDown;
     

            DrawingCanvas.Children.Add(ALine);

        }

       
        private void ALine_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Line l = sender as Line;


            ClickedLineLength = l.X1 - l.X2;


            DragStartPoint.X = e.GetPosition(this).X;
            DragStartPoint.Y = e.GetPosition(this).Y;

            ObjectStartLocation.X = l.X1;
            ObjectStartLocation.Y = l.Y1;
           


            ClickedObject = sender as Line;
            
        }

        private void DrawingCanvas_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ClickedObject = null;
        }

        private void DrawingCanvas_PreviewMouseMove(object sender, MouseEventArgs e)
        {



            if (ClickedObject == null)
                return;



            DragEndPoint.X = e.GetPosition(this).X;
            DragEndPoint.Y = e.GetPosition(this).Y;

            double deltaX = DragEndPoint.X - DragStartPoint.X;
            double deltaY = DragEndPoint.Y - DragStartPoint.Y;

            if (ClickedObject is Line)
            {
                Line l = ClickedObject as Line;

                l.X1 = ObjectStartLocation.X + deltaX;
                l.X2 = l.X1 + ClickedLineLength;

                l.Y1 = ObjectStartLocation.Y + deltaY;
                l.Y2 = ObjectStartLocation.Y + deltaY;

                
            }
            else if (ClickedObject is Rectangle)
            {
                Rectangle r = ClickedObject as Rectangle;

                Canvas.SetLeft(r, ObjectStartLocation.X + deltaX);
                Canvas.SetTop (r, ObjectStartLocation.Y + deltaY);

                
            }
            else if (ClickedObject is Ellipse)
            {

                Ellipse c = ClickedObject as Ellipse;

                Canvas.SetLeft(c, ObjectStartLocation.X + deltaX);
                Canvas.SetTop (c, ObjectStartLocation.Y + deltaY);
               
            }
            else
                return;


        }

      


    }
}
